import Foundation

final class Score {
    
    static let instance = Score()
    
    var gemPoints: Int32
    var score: Int32
    
    private init() {
        self.score = 0
        self.gemPoints = 10
    }
    
    func create(score: Int32, gemPoints: Int32) {
        self.score = score
        self.gemPoints = gemPoints
    }
    
    func add(score: Int32) {
        self.score += score
    }
    
    func get() -> Int32 {
        return self.score
    }
    
    func reset() {
        self.score = 0
    }
    
    func reset(gemPoints: Int32) {
        self.score = 0
        self.gemPoints = gemPoints
    }
}
