import Foundation
import Firebase
import FirebaseDatabase

public class DatabaseHelper {
    
    var ref: FIRDatabaseReference!
    
    
    init() {
        // do initial setup or establish an initial connection
        self.ref = FIRDatabase.database().reference()
    }
    
    /**
     * Retreives highscores
     *
     * When finished, GameScene::onHighscoresRetreived() called
     */
    func retreiveHighscores(_ context: GameScene) {
        self.ref.observeSingleEvent(of: .value, with: { (snapshot) in
            let value = snapshot.value as? NSDictionary
            
            let scores: NSMutableDictionary = [:]
            
            for i in 1...10 {
                if let user = value?["username" + String(i)] as? String, let score = value?["score" + String(i)] as? Int32 {
                    if user == "" {
                        continue
                    }
                    scores[user] = score
                }
            }
            
            context.onHighscoresRetreived(scores)
        })
    }
    
    /**
     * Adds a score to the leaderboard (removes the 10th spot)
     */
    func add(score: Int32, forUser user: String) {
        self.ref.observeSingleEvent(of: .value, with: { (snapshot) in
            let value = snapshot.value as? NSDictionary
            
            var usernames = [String]()
            var scores = [Int32]()
            
            for i in 1...10 {
                usernames.append(value?["username" + String(i)] as? String ?? "")
                scores.append(value?["score" + String(i)] as? Int32 ?? 0)
            }
            
            var i = 1
            var inserted = false
            while i <= 10 && !inserted {
                if score > scores[i-1] {
                    self.ref.child("username" + String(i)).setValue(user)
                    self.ref.child("score" + String(i)).setValue(score)
                    inserted = true
                } else {
                    self.ref.child("username" + String(i)).setValue(usernames[i-1])
                    self.ref.child("score" + String(i)).setValue(scores[i-1])
                }
                
                i += 1
            }
            if inserted {
                while i <= 10 {
                    self.ref.child("username" + String(i)).setValue(usernames[i-2])
                    self.ref.child("score" + String(i)).setValue(scores[i-2])
                    
                    i += 1
                }
            }
        })
    }
}
