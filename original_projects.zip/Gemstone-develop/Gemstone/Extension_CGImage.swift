//
//  Extension_CGImage.swift
//  Gemstone
//
//  Created by Jason Lee on 2017-03-20.
//  Copyright © 2017 Gemstone Production. All rights reserved.
//

import UIKit

extension CGImage {
    func equals(_ img: CGImage) -> Bool {
        let img1 = UIImage(cgImage: self)
        let img2 = UIImage(cgImage: img)
        
        guard let data1 = UIImagePNGRepresentation(img1) else { return false }
        guard let data2 = UIImagePNGRepresentation(img2) else { return false }
        
        return data1.elementsEqual(data2)
    }
}
