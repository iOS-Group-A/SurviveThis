import SpriteKit

struct PhysicsCategory {
    static let None      : UInt32 = 0
    static let All       : UInt32 = UInt32.max
    static let Monster   : UInt32 = 0b1       // 1
    static let Projectile: UInt32 = 0b10      // 2
}


func + (left: CGPoint, right: CGPoint) -> CGPoint {
    return CGPoint(x: left.x + right.x, y: left.y + right.y)
}

func - (left: CGPoint, right: CGPoint) -> CGPoint {
    return CGPoint(x: left.x - right.x, y: left.y - right.y)
}

func * (point: CGPoint, scalar: CGFloat) -> CGPoint {
    return CGPoint(x: point.x * scalar, y: point.y * scalar)
}

func / (point: CGPoint, scalar: CGFloat) -> CGPoint {
    return CGPoint(x: point.x / scalar, y: point.y / scalar)
}

#if !(arch(x86_64) || arch(arm64))
    func sqrt(a: CGFloat) -> CGFloat {
        return CGFloat(sqrtf(Float(a)))
    }
#endif

extension CGPoint {
    func length() -> CGFloat {
        return sqrt(x*x + y*y)
    }
    
    func normalized() -> CGPoint {
        return self / length()
    }
}

class GameScene: SKScene, SKPhysicsContactDelegate {
    let dbHelper = DatabaseHelper()
    let score = Score.instance
    var lives: Int?
    
    let phRatio1: CGFloat = 10 / 16
    let phRatio2: CGFloat = 30 / 16
    
    var swipeLine: CGFloat?
    var topLine: CGFloat?
    
    var phLeft1: SKSpriteNode  = SKSpriteNode(imageNamed: "gem_lightblue")
    var phLeft2: SKSpriteNode  = SKSpriteNode(imageNamed: "gem_pink")
    var phRight1: SKSpriteNode = SKSpriteNode(imageNamed: "gem_orange")
    var phRight2: SKSpriteNode = SKSpriteNode(imageNamed: "gem_diamond")
    
    
    func onHighscoresRetreived(_ scores: NSMutableDictionary) {
        print(scores)
    }
    
    func loseLive() {
        self.lives! -= 1
        if self.lives! <= 0 {
            // game over
            print("Inside lives <= 0")
            let loseAction = SKAction.run {
                print("Inside lose animation runner part")
                let reveal = SKTransition.flipHorizontal(withDuration: 0.5)
                let gameOverScene = GameOverScene(size: self.size, score: self.score.get())
                self.view?.presentScene(gameOverScene, transition: reveal)
            }
            self.phLeft1.run(loseAction)
        }
    }
    
    func swipeRight(sender: UISwipeGestureRecognizer) {
        let point: CGPoint = sender.location(in: sender.view!)
        if sender.state == .ended {
            if size.height - point.y > swipeLine! {
                enumerateChildNodes(withName: "//*", using: { (node, unsafePointer) in
                    if node.position.y > self.swipeLine! && node.position.y < self.topLine! {
                        // TOP RIGHT SWIPE GEM
                        if node.name != "placeholder1" && node.name != "placeholder2"
                            && node.name != "placeholder3" && node.name != "placeholder4" {
                            node.removeAllActions()
                            let goRight = SKAction.move(to: CGPoint(x: self.size.width + node.position.x, y: node.position.y), duration: 0.3)
                            let removeFromParent = SKAction.removeFromParent()
                            
                            let handleCollision = SKAction.run {
                                let currentNode = node as! SKSpriteNode
                                if currentNode.texture!.cgImage().equals(self.phRight2.texture!.cgImage()) {
                                    print("Correct!")
                                    self.score.add(score: 10)
                                } else {
                                    print("WRONG!!!")
                                    self.loseLive()
                                }
                            }
                            node.run(SKAction.sequence([goRight, handleCollision, removeFromParent]))
                        }
                    }
                })
            } else {
                enumerateChildNodes(withName: "//*", using: { (node, unsafePointer) in
                    if node.position.y < self.swipeLine! {
                        // BOTTOM RIGHT SWIPE GEM
                        if node.name != "placeholder1" && node.name != "placeholder2"
                            && node.name != "placeholder3" && node.name != "placeholder4" {
                            node.removeAllActions()
                            let goRight = SKAction.move(to: CGPoint(x: self.size.width + node.position.x, y: node.position.y), duration: 0.3)
                            let removeFromParent = SKAction.removeFromParent()
                            
                            let handleCollision = SKAction.run {
                                if !(node is SKAudioNode) {
                                    let currentNode = node as! SKSpriteNode
                                    if currentNode.texture!.cgImage().equals(self.phRight1.texture!.cgImage()) {
                                        print("Correct!")
                                        self.score.add(score: 10)
                                    } else {
                                        print("WRONG!!!")
                                        self.loseLive()
                                    }
                                }
                            }
                            node.run(SKAction.sequence([goRight, handleCollision, removeFromParent]))
                        }
                    }
                })
            }
        }
    }
    
    func swipeLeft(sender:UISwipeGestureRecognizer) {
        let point: CGPoint = sender.location(in: sender.view!)
        if sender.state == .ended {
            if size.height - point.y > swipeLine! {
                enumerateChildNodes(withName: "//*", using: { (node, unsafePointer) in
                    if node.position.y > self.swipeLine! && node.position.y < self.topLine! {
                        // WE IN THE TOP LEFT SWIPE GEM
                        if node.name != "placeholder1" && node.name != "placeholder2"
                            && node.name != "placeholder3" && node.name != "placeholder4" {
                            node.removeAllActions()
                            let goLeft = SKAction.move(to: CGPoint(x: -node.position.x, y: node.position.y), duration: 0.3)
                            let removeFromParent = SKAction.removeFromParent()
                            
                            let handleCollision = SKAction.run {
                                let currentNode = node as! SKSpriteNode
                                if currentNode.texture!.cgImage().equals(self.phLeft2.texture!.cgImage()) {
                                    print("Correct!")
                                    self.score.add(score: 10)
                                } else {
                                    print("WRONG!!!")
                                    self.loseLive()
                                }
                            }
                            node.run(SKAction.sequence([goLeft, handleCollision, removeFromParent]))
                        }
                    }
                })
            } else {
                enumerateChildNodes(withName: "//*", using: { (node, unsafePointer) in
                    if node.position.y < self.swipeLine! {
                        // THE BOTTOM LEFT SWIPE GEM
                        if node.name != "placeholder1" && node.name != "placeholder2"
                            && node.name != "placeholder3" && node.name != "placeholder4" {
                            node.removeAllActions()
                            let goLeft = SKAction.move(to: CGPoint(x: -node.position.x, y: node.position.y), duration: 0.3)
                            let removeFromParent = SKAction.removeFromParent()
                            
                            let handleCollision = SKAction.run {
                                if !(node is SKAudioNode) {
                                    let currentNode = node as! SKSpriteNode
                                    if currentNode.texture!.cgImage().equals(self.phLeft1.texture!.cgImage()) {
                                        print("Correct!")
                                        self.score.add(score: 10)
                                    } else {
                                        print("WRONG!!!")
                                        self.loseLive()
                                    }
                                }
                            }
                            node.run(SKAction.sequence([goLeft, handleCollision, removeFromParent]))
                        }
                    }
                })
            }
        }
    }
    
    override func didMove(to view: SKView) {
        // TEST
        dbHelper.retreiveHighscores(self)
        
        self.score.reset()
        self.lives = 3
        
        phLeft1.name = "placeholder1"
        phLeft2.name = "placeholder2"
        phRight1.name = "placeholder3"
        phRight2.name = "placeholder4"
        
        // swipe listeners
        let swipeRight: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(self.swipeRight))
        swipeRight.direction = .right
        view.addGestureRecognizer(swipeRight)
        
        let swipeLeft: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(self.swipeLeft))
        swipeLeft.direction = .left
        view.addGestureRecognizer(swipeLeft)
        
        let phHeight1 = phRatio1 * phLeft1.size.height
        let phHeight2 = phRatio2 * phLeft1.size.height
        
        swipeLine = (phHeight1 + phHeight2) / 2
        topLine = swipeLine! * 2
        
        backgroundColor = SKColor.white
                
        phLeft1.position = CGPoint(x: 0, y: phHeight1)
        phLeft2.position = CGPoint(x: 0, y: phHeight2)
        phRight1.position = CGPoint(x: size.width, y: phHeight1)
        phRight2.position = CGPoint(x: size.width, y: phHeight2)
        
        phLeft1.alpha = 0.5
        phLeft2.alpha = 0.5
        phRight1.alpha = 0.5
        phRight2.alpha = 0.5
        
        addChild(phLeft1)
        addChild(phLeft2)
        addChild(phRight1)
        addChild(phRight2)
        
        physicsWorld.gravity = CGVector.zero
        physicsWorld.contactDelegate = self
        
        run(SKAction.repeatForever(
            SKAction.sequence([
                SKAction.run(gemGenerator),
                SKAction.wait(forDuration: 1.2)
                ])
        ))
        
        let backgroundMusic = SKAudioNode(fileNamed: "background-music-aac.caf")
        backgroundMusic.autoplayLooped = true
        addChild(backgroundMusic)
        
    }
    
    func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    
    func random(min: CGFloat, max: CGFloat) -> CGFloat {
        return random() * (max - min) + min
    }
    
    func gemGenerator() {
        var gem: SKSpriteNode = SKSpriteNode(imageNamed: "gem_lightblue")
        // Create sprite
        let gemRand = arc4random_uniform(4) // MAKE THIS 5 (4 for testing)
        
        switch gemRand {
        case 0:
            gem = SKSpriteNode(imageNamed: "gem_lightblue")
        case 1:
            gem = SKSpriteNode(imageNamed: "gem_orange")
        case 2:
            gem = SKSpriteNode(imageNamed: "gem_diamond")
        case 3:
            gem = SKSpriteNode(imageNamed: "gem_pink")
        case 4:
            gem = SKSpriteNode(imageNamed: "gem_green")
        default: break
        }
        
        
        
        let randomX = arc4random_uniform(3)
        
        var actualX = size.width / 2
        switch randomX {
        case 0:
            actualX = 3 * size.width / CGFloat(8.0)
        case 1:
            actualX = 4 * size.width / CGFloat(8.0)
        case 2:
            actualX = 5 * size.width / CGFloat(8.0)
        default: break
        }
        //let actualX = size.width/2 //random(min: monster.size.width/2, max: size.width - monster.size.width/2)
        
        
        gem.physicsBody = SKPhysicsBody(rectangleOf: gem.size) // 1
        gem.physicsBody?.isDynamic = true // 2
        gem.physicsBody?.categoryBitMask = PhysicsCategory.Monster // 3
        gem.physicsBody?.contactTestBitMask = PhysicsCategory.Projectile // 4
        gem.physicsBody?.collisionBitMask = PhysicsCategory.None // 5
        
        gem.position = CGPoint(x: actualX, y: size.height + gem.size.height/2)
        
        // Add the monster to the scene
        addChild(gem)
        
        // Determine speed of the gem
        let actualDuration = CGFloat(4.0)
        
        // Create the actions
        let actionMove = SKAction.move(to: CGPoint(x: actualX, y: -gem.size.height/2), duration: TimeInterval(actualDuration))
        
        let actionMoveDone = SKAction.removeFromParent()
        
        let reachedEndAction = SKAction.run() {
            self.loseLive()
            /*
            let reveal = SKTransition.flipHorizontal(withDuration: 0.5)
            let gameOverScene = GameOverScene(size: self.size, won: false)
            self.view?.presentScene(gameOverScene, transition: reveal)
             */
        }
        gem.run(SKAction.sequence([actionMove, reachedEndAction, actionMoveDone]))
 
    }
    
    
    
}
