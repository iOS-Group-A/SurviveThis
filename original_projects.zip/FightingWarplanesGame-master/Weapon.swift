//
//  Weapon.swift
//  FightingWarplanes
//
//  Created by 裴雷 on 15/02/2017.
//  Copyright © 2017 Rachel Liu. All rights reserved.
//

import SpriteKit

/**
 this is the base class for all the weapons
 */
class Weapon : SKSpriteNode {
    
    private var _type : Weapon?
    
    var type : Weapon {
        get {
            return _type!
        } set {
            _type = newValue
        }
    }
    
}
