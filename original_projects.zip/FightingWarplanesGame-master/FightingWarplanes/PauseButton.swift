//
//  PauseButton.swift
//  FightingWarplanes
//
//  Created by Wayne Wang on 2017-02-16.
//  Copyright © 2017 Rachel Liu. All rights reserved.
//

import Foundation
import SpriteKit

