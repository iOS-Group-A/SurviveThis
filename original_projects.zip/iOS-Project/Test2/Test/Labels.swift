//
//  Labels.swift
//  Test
//
//  Created by Dalton Danis on 2017-03-02.
//  Copyright © 2017 Dalton Danis. All rights reserved.
//

import Foundation
import SpriteKit

func getHealth() -> SKLabelNode {
    let healthLabel = SKLabelNode(text: "Health: \(Settings.Game.health)")
    
    healthLabel.fontName = "Comic Sans MS-bold"
    healthLabel.horizontalAlignmentMode = .left
    
    return healthLabel
}

func getWave() -> SKLabelNode {
    let waveLabel = SKLabelNode(text: "Wave: 0")
    
    waveLabel.fontName = "Comic Sans MS-bold"
    waveLabel.text = "Wave: \(Settings.Game.initWaveNo)"
    waveLabel.horizontalAlignmentMode = .left
    
    return waveLabel
}

func getScore() -> SKLabelNode {
    let scoreLabel = SKLabelNode(text: "Score: 0")
    scoreLabel.fontName = "AmericanTypewriter-Bold"
    scoreLabel.fontSize = 20
    scoreLabel.fontColor = UIColor.white
    
    return scoreLabel
}

// RYAN ADDED THIS
func getRemaining() -> SKLabelNode{
    let remainingLabel = SKLabelNode(text: "4")
    
    remainingLabel.fontName = "Comic Sans MS-bold"
    remainingLabel.text = "\(Settings.Game.initNumOfMonsters)"
    remainingLabel.horizontalAlignmentMode = .left
    remainingLabel.position = CGPoint(x: 220, y: -155.25)
    
    return remainingLabel
}
